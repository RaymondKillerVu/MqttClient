# dmap2gcode
Dmap2gcode generates g-code to cut depth based on a gray scale image darkness or lightness. 
This version generates gcode that works with MarlinFirmware.

The original dmap2gcode can be found here: http://www.scorchworks.com/Dmap2gcode/dmap2gcode.html



