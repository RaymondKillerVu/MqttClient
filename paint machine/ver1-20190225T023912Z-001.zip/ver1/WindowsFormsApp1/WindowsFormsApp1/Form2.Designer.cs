﻿namespace WindowsFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            this.s130text = new System.Windows.Forms.TextBox();
            this.s131text = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.s132text = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.s0text = new System.Windows.Forms.TextBox();
            this.s1text = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.s3text = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.s13text = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.s12text = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.s5text = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.s27text = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.s26text = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.s25text = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.s24text = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.s23text = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.s21text = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.s20text = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(589, 244);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "s130";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "read";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(111, 12);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(75, 23);
            this.save.TabIndex = 4;
            this.save.Text = "save";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // s130text
            // 
            this.s130text.Location = new System.Drawing.Point(656, 241);
            this.s130text.Name = "s130text";
            this.s130text.Size = new System.Drawing.Size(100, 20);
            this.s130text.TabIndex = 5;
            this.s130text.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // s131text
            // 
            this.s131text.Location = new System.Drawing.Point(656, 166);
            this.s131text.Name = "s131text";
            this.s131text.Size = new System.Drawing.Size(100, 20);
            this.s131text.TabIndex = 8;
            this.s131text.TextChanged += new System.EventHandler(this.s101text_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(589, 169);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "s131";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // s132text
            // 
            this.s132text.Location = new System.Drawing.Point(656, 205);
            this.s132text.Name = "s132text";
            this.s132text.Size = new System.Drawing.Size(100, 20);
            this.s132text.TabIndex = 11;
            this.s132text.TextChanged += new System.EventHandler(this.s102text_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(589, 208);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "s132";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(123, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "s0";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // s0text
            // 
            this.s0text.Location = new System.Drawing.Point(179, 125);
            this.s0text.Name = "s0text";
            this.s0text.Size = new System.Drawing.Size(100, 20);
            this.s0text.TabIndex = 14;
            this.s0text.TextChanged += new System.EventHandler(this.s0text_TextChanged);
            // 
            // s1text
            // 
            this.s1text.Location = new System.Drawing.Point(179, 164);
            this.s1text.Name = "s1text";
            this.s1text.Size = new System.Drawing.Size(100, 20);
            this.s1text.TabIndex = 16;
            this.s1text.TextChanged += new System.EventHandler(this.s1text_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(123, 168);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "s1";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // s3text
            // 
            this.s3text.Location = new System.Drawing.Point(179, 203);
            this.s3text.Name = "s3text";
            this.s3text.Size = new System.Drawing.Size(100, 20);
            this.s3text.TabIndex = 18;
            this.s3text.TextChanged += new System.EventHandler(this.s3text_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(123, 207);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "dir_axis";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // s13text
            // 
            this.s13text.Location = new System.Drawing.Point(179, 317);
            this.s13text.Name = "s13text";
            this.s13text.Size = new System.Drawing.Size(100, 20);
            this.s13text.TabIndex = 24;
            this.s13text.TextChanged += new System.EventHandler(this.s13text_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(123, 321);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "cm/in";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // s12text
            // 
            this.s12text.Location = new System.Drawing.Point(179, 278);
            this.s12text.Name = "s12text";
            this.s12text.Size = new System.Drawing.Size(100, 20);
            this.s12text.TabIndex = 22;
            this.s12text.TextChanged += new System.EventHandler(this.s12text_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(123, 282);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "s12";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // s5text
            // 
            this.s5text.Location = new System.Drawing.Point(179, 239);
            this.s5text.Name = "s5text";
            this.s5text.Size = new System.Drawing.Size(100, 20);
            this.s5text.TabIndex = 20;
            this.s5text.TextChanged += new System.EventHandler(this.s5text_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(123, 243);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(18, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "s5";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // s27text
            // 
            this.s27text.Location = new System.Drawing.Point(656, 127);
            this.s27text.Name = "s27text";
            this.s27text.Size = new System.Drawing.Size(100, 20);
            this.s27text.TabIndex = 36;
            this.s27text.TextChanged += new System.EventHandler(this.s27text_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(589, 129);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(24, 13);
            this.label10.TabIndex = 35;
            this.label10.Text = "s27";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // s26text
            // 
            this.s26text.Location = new System.Drawing.Point(414, 279);
            this.s26text.Name = "s26text";
            this.s26text.Size = new System.Drawing.Size(100, 20);
            this.s26text.TabIndex = 34;
            this.s26text.TextChanged += new System.EventHandler(this.s26text_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(358, 283);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 13);
            this.label11.TabIndex = 33;
            this.label11.Text = "s26";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // s25text
            // 
            this.s25text.Location = new System.Drawing.Point(414, 240);
            this.s25text.Name = "s25text";
            this.s25text.Size = new System.Drawing.Size(100, 20);
            this.s25text.TabIndex = 32;
            this.s25text.TextChanged += new System.EventHandler(this.s25text_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(358, 244);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(24, 13);
            this.label12.TabIndex = 31;
            this.label12.Text = "s25";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // s24text
            // 
            this.s24text.Location = new System.Drawing.Point(414, 204);
            this.s24text.Name = "s24text";
            this.s24text.Size = new System.Drawing.Size(100, 20);
            this.s24text.TabIndex = 30;
            this.s24text.TextChanged += new System.EventHandler(this.s24text_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(358, 208);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(24, 13);
            this.label13.TabIndex = 29;
            this.label13.Text = "s24";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // s23text
            // 
            this.s23text.Location = new System.Drawing.Point(414, 165);
            this.s23text.Name = "s23text";
            this.s23text.Size = new System.Drawing.Size(100, 20);
            this.s23text.TabIndex = 28;
            this.s23text.TextChanged += new System.EventHandler(this.s23text_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(358, 169);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 13);
            this.label14.TabIndex = 27;
            this.label14.Text = "dir_home";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // s21text
            // 
            this.s21text.Location = new System.Drawing.Point(414, 126);
            this.s21text.Name = "s21text";
            this.s21text.Size = new System.Drawing.Size(100, 20);
            this.s21text.TabIndex = 26;
            this.s21text.TextChanged += new System.EventHandler(this.s21text_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(358, 130);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 13);
            this.label15.TabIndex = 25;
            this.label15.Text = "EndStop";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // s20text
            // 
            this.s20text.Location = new System.Drawing.Point(414, 314);
            this.s20text.Name = "s20text";
            this.s20text.Size = new System.Drawing.Size(100, 20);
            this.s20text.TabIndex = 38;
            this.s20text.TextChanged += new System.EventHandler(this.s20text_TextChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(358, 318);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(24, 13);
            this.label16.TabIndex = 37;
            this.label16.Text = "s20";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(934, 450);
            this.Controls.Add(this.s20text);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.s27text);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.s26text);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.s25text);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.s24text);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.s23text);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.s21text);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.s13text);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.s12text);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.s5text);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.s3text);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.s1text);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.s0text);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.s132text);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.s131text);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.s130text);
            this.Controls.Add(this.save);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.TextBox s130text;
        private System.Windows.Forms.TextBox s131text;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox s132text;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox s0text;
        private System.Windows.Forms.TextBox s1text;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox s3text;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox s13text;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox s12text;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox s5text;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox s27text;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox s26text;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox s25text;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox s24text;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox s23text;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox s21text;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox s20text;
        private System.Windows.Forms.Label label16;
    }
}